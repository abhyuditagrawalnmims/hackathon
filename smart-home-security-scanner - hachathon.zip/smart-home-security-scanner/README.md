# Smart Home Security Scanner

## Overview
The Smart Home Security Scanner is a tool designed to enhance the security of connected devices in a smart home network. It identifies devices, scans for vulnerabilities, and provides actionable recommendations to improve overall system integrity. This project combines network scanning, vulnerability assessment, and a user-friendly dashboard.

---

## Features
1. **Device Discovery**: Scans the local network to identify all connected devices, including their IP and MAC addresses.
2. **Vulnerability Assessment**: Checks each device against known vulnerabilities from databases like CVE.
3. **Threat Assessment**: Evaluates the severity and impact of discovered vulnerabilities.
4. **Actionable Recommendations**: Provides clear steps to mitigate identified risks.
5. **User-Friendly Dashboard**: Displays scan results and recommendations in an interactive web interface.

---

## Installation

### Prerequisites
- Python 3.8+
- pip (Python package manager)

### Clone the Repository
```bash
git clone https://github.com/your-repo/smart-home-security-scanner.git
cd smart-home-security-scanner
```

### Install Dependencies
```bash
pip install -r requirements.txt
```

---

## Configuration

### Environment Variables
Create a `.env` file in the root directory and define the following variables:
```env
FLASK_APP=run.py
FLASK_ENV=development
NETWORK_IP_RANGE=192.168.1.1/24
```
- `FLASK_APP`: The entry point of the application.
- `FLASK_ENV`: Set to `development` for debugging or `production` for deployment.
- `NETWORK_IP_RANGE`: The IP range to scan for connected devices.

---

## Running the Application
1. Start the Flask server:
   ```bash
   python run.py
   ```
2. Open your browser and navigate to `http://127.0.0.1:5000`.

---

## File Structure
```plaintext
smart-home-security-scanner/
├── app/
│   ├── scanner.py          # Handles network scanning
│   ├── vulnerabilities.py  # Checks vulnerabilities
│   ├── recommendations.py  # Generates recommendations
│   ├── dashboard.py        # Flask-based web dashboard
│   ├── utils.py            # Helper functions
├── requirements.txt        # Python dependencies
├── README.md               # Documentation
├── .env                    # Environment variables
└── run.py                  # Main entry point
```

---

## Future Enhancements
1. **AI/ML Integration**: Use machine learning to predict vulnerabilities based on device behavior.
2. **Cloud Support**: Add cloud-based logging and analytics.
3. **Automated Fixes**: Enable automatic application of security recommendations.

---

## License
[MIT License](LICENSE)

---

## Acknowledgments
- [Scapy](https://scapy.net/) for network scanning.
- [Flask](https://flask.palletsprojects.com/) for building the web application.
- [NVD](https://nvd.nist.gov/) for vulnerability data.

---

## Contributing
Contributions are welcome! Please fork the repository and submit a pull request with your improvements.
