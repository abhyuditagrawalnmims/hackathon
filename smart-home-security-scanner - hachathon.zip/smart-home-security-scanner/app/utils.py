import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def get_network_ip_range():
    """
    Fetches the IP range to scan from environment variables.
    Default is 192.168.1.1/24 if not set.
    """
    return os.getenv("NETWORK_IP_RANGE", "192.168.1.1/24")

def format_mac_address(mac):
    """
    Formats a MAC address to be more readable.
    Example: '00:11:22:33:44:55' -> '00-11-22-33-44-55'
    """
    return mac.upper().replace(":", "-")

def validate_ip(ip):
    """
    Validates if a string is a valid IP address.
    Returns True if valid, False otherwise.
    """
    import socket
    try:
        socket.inet_aton(ip)
        return True
    except socket.error:
        return False

def save_scan_results(results, file_path="scan_results.json"):
    """
    Saves the scan results to a JSON file.
    """
    import json
    with open(file_path, "w") as f:
        json.dump(results, f, indent=4)

def load_scan_results(file_path="scan_results.json"):
    """
    Loads scan results from a JSON file if it exists.
    """
    import json
    if os.path.exists(file_path):
        with open(file_path, "r") as f:
            return json.load(f)
    return {}
