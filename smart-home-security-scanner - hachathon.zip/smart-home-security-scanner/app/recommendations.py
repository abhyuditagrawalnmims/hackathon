def generate_recommendations(vulnerabilities):
    """
    Provides recommendations based on vulnerabilities.
    """
    recommendations = []
    for vulnerability in vulnerabilities:
        if "default password" in vulnerability["description"].lower():
            recommendations.append("Change the default password immediately.")
        elif "unpatched firmware" in vulnerability["description"].lower():
            recommendations.append("Update the device firmware to the latest version.")
    return recommendations

if __name__ == "__main__":
    vulnerabilities = [
        {"id": "CVE-2021-12345", "description": "Weak default password"},
        {"id": "CVE-2022-67890", "description": "Unpatched firmware"}
    ]
    recs = generate_recommendations(vulnerabilities)
    print(recs)
