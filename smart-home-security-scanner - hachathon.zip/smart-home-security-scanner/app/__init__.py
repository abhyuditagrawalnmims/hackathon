# app/__init__.py
from flask import Flask

app = Flask(__name__)

# Import routes here (if any)
from app import dashboard
