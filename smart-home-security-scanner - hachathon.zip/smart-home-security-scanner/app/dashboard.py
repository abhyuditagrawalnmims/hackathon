from flask import Flask, render_template, jsonify
from scanner import scan_network
from vulnerabilities import check_vulnerabilities
from recommendations import generate_recommendations

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/scan")
def scan():
    devices = scan_network("192.168.1.1/24")
    results = []
    for device in devices:
        vulnerabilities = check_vulnerabilities(device)
        recommendations = generate_recommendations(vulnerabilities["vulnerabilities"])
        results.append({
            "device": device,
            "vulnerabilities": vulnerabilities,
            "recommendations": recommendations
        })
    return jsonify(results)

if __name__ == "__main__":
    app.run(debug=True)
