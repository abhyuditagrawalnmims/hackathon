import scapy.all as scapy

def scan_network(ip_range):
    """
    Scans the given IP range to discover devices.
    """
    arp_request = scapy.ARP(pdst=ip_range)
    broadcast = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
    arp_request_broadcast = broadcast / arp_request
    answered = scapy.srp(arp_request_broadcast, timeout=2, verbose=False)[0]

    devices = []
    for element in answered:
        devices.append({
            "ip": element[1].psrc,
            "mac": element[1].hwsrc
        })
    return devices

if __name__ == "__main__":
    devices = scan_network("192.168.1.1/24")
    print("Devices Found:")
    for device in devices:
        print(device)
